# Chain Chat – Secure Decentralized Chat Application

## Overview
Chain Chat is a decentralized and secure messaging application built using blockchain technology.

## Features
- Secure user authentication
- Blockchain-based messaging
- IPFS integration
- Smart contract integration
- Modern responsive UI

## Tech Stack
- React.js
- TypeScript
- Vite
- Solidity
- Hardhat
- Ethers.js
- IPFS (Pinata)

## Installation

```bash
npm install
npm run dev
```

## Environment Variables

Create a .env file using .env.example.

## Security
Never commit your .env file or private keys.

## License
MIT
